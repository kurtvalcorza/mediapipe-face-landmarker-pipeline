"""P5: repeated Run all in one kernel, then a partial re-run (Section 1 cell, then the Section 4 cell)."""
import json, sys, time
import nbformat
from nbclient import NotebookClient
nb = nbformat.read(sys.argv[1], as_version=4)
client = NotebookClient(nb, timeout=1800, kernel_name="python3", resources={"metadata": {"path": sys.argv[2]}})
code = [i for i, c in enumerate(nb.cells) if c.cell_type == "code"]
log = []
with client.setup_kernel():
    for rnd in (1, 2):
        t = time.time()
        for i in code:
            client.execute_cell(nb.cells[i], i)
        log.append({"pass": rnd, "seconds": round(time.time() - t, 1)})
        for i in (6, 12, 15, 18):
            txt = "".join(o.get("text", "") for o in nb.cells[i].outputs)
            log.append({"pass": rnd, "cell": i, "out": [l[:240] for l in txt.splitlines() if "setup_seconds" in l or "fetched" in l or "run_directory" in l]})
    # partial re-run: Section 1 only, then Section 4
    client.execute_cell(nb.cells[6], 6)
    try:
        client.execute_cell(nb.cells[18], 18)
        log.append({"partial": "cell 18 succeeded"})
    except Exception as exc:  # CellExecutionError
        txt = "".join(o.get("text", "") for o in nb.cells[18].outputs)
        log.append({"partial": "cell 18 failed", "error": str(exc).strip().splitlines()[-1][:300], "stream": txt[-600:]})
print(json.dumps(log, indent=1))
