"""Review probes for mediapipe_face_landmarker_colab (Notebook Review Framework v1).

Run with the isolated interpreter the notebook built (mediapipe 1.0.0 from the carried lock) after a default Run all:

    <venv>/bin/python run_probes.py --run <run directory> --weights <weights directory> --out <probe output dir>

P2  180-degree mechanism: where the landmarks land on the rotated image (is the mesh on the face, fitted the wrong way
    up, or off the face?), plus a rotation sweep with the notebook's own perturbation_table.
P3  VIDEO-mode comparison re-scored against the composite's own annotation (moved by the known roll) instead of the
    IMAGE-mode still prediction.
P6  What the exported records hold (probe outcomes, faces_returned, file listing).
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", type=Path, required=True)
    ap.add_argument("--weights", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    a = ap.parse_args()
    a.out.mkdir(parents=True, exist_ok=True)
    sys.path.insert(0, str(a.run / "src"))
    sys.path.insert(0, str(a.run))
    import tutorial_stages as ts
    from mediapipe_face_landmarker_pipeline import (
        EYE_CORNERS,
        MEDIAPIPE_INDICES,
        apply_affine,
        draw_overlay,
        inter_ocular_distance,
        nme_iod,
        perturb,
        read_template,
        template_subset,
        validate_image,
    )

    opts = argparse.Namespace(byod="", num_faces=1, rotation=120.0)
    run = ts.Run(a.run, a.weights, opts)
    records = ts.load_records(run, "probe")
    results: dict = {}

    # ---------------- P2: 180 degrees ----------------
    subset = records["neutral"][: ts.ROBUSTNESS_FACES]
    p2 = []
    tiles = []
    with ts.make_landmarker(run, num_faces=1) as lm:
        for rec in subset:
            image, _ = validate_image(rec["image_path"], image_id=rec["id"])
            rotated, forward = perturb(image, "rotate", 180.0)
            faces = lm.detect(rotated)
            truth = template_subset(read_template(rec["template_path"]))
            truth_rot = apply_affine(forward, truth)  # annotation in the rotated frame
            row = {"id": rec["id"], "faces": len(faces)}
            if faces:
                w, h = rotated.size
                pts = faces[0]["landmarks"][:, :2] * np.array([w, h])
                # in a 180-degree image a correctly fitted mesh has the chin (152) ABOVE the forehead (10)
                row["chin_y"] = round(float(pts[152, 1]), 1)
                row["forehead_y"] = round(float(pts[10, 1]), 1)
                row["mesh_upright_in_rotated_frame"] = bool(pts[152, 1] > pts[10, 1])
                pred = pts[list(MEDIAPIPE_INDICES)]
                iod = inter_ocular_distance(truth, EYE_CORNERS)
                row["nme_in_rotated_frame"] = round(nme_iod(pred, truth_rot, iod), 4)
                # same points, but compared with the annotation reflected through the face centre (an upside-down fit)
                centre = truth_rot.mean(axis=0)
                flipped = 2 * centre - truth_rot
                # swap left/right names too for a 180-degree in-plane flip of label order? (not needed: rotation keeps
                # handedness; a mesh fitted upright on an upside-down face mirrors vertically only)
                mirrored = truth_rot.copy()
                mirrored[:, 1] = 2 * centre[1] - truth_rot[:, 1]
                row["nme_vs_vertically_mirrored_annotation"] = round(nme_iod(pred, mirrored, iod), 4)
                row["nme_vs_point_reflected_annotation"] = round(nme_iod(pred, flipped, iod), 4)
                box = pts.min(axis=0), pts.max(axis=0)
                tb = truth_rot.min(axis=0), truth_rot.max(axis=0)
                row["mesh_box"] = [round(float(v), 0) for v in (*box[0], *box[1])]
                row["annotation_box"] = [round(float(v), 0) for v in (*tb[0], *tb[1])]
            p2.append(row)
            if len(tiles) < 4:
                tiles.append(draw_overlay(rotated, faces, highlight=MEDIAPIPE_INDICES, max_side=400))
    from mediapipe_face_landmarker_pipeline import contact_sheet

    contact_sheet(tiles, columns=4, tile=360, labels=[r["id"] for r in p2[:4]]).save(a.out / "p2_rot180_overlays.jpg", quality=88)
    results["P2_rot180"] = p2
    det = [r for r in p2 if r["faces"]]
    results["P2_summary"] = {
        "faces": len(p2),
        "detected": len(det),
        "mesh_upright_in_rotated_frame": sum(r["mesh_upright_in_rotated_frame"] for r in det),
        "median_nme_in_rotated_frame": float(np.median([r["nme_in_rotated_frame"] for r in det])) if det else None,
        "median_nme_vs_vertically_mirrored": float(np.median([r["nme_vs_vertically_mirrored_annotation"] for r in det])) if det else None,
        "median_nme_vs_point_reflected": float(np.median([r["nme_vs_point_reflected_annotation"] for r in det])) if det else None,
    }
    with ts.make_landmarker(run, num_faces=1) as lm:
        sweep = ts.perturbation_table(run, lm, subset, [("rotate", v) for v in (100.0, 120.0, 135.0, 150.0, 165.0, -120.0, -150.0)])
    results["P2_sweep"] = sweep

    # ---------------- P3: VIDEO mode against the annotation ----------------
    rec = ts.by_id(records)[ts.VIDEO_ID]
    image, _ = validate_image(rec["image_path"])
    sx = 600 / image.size[0]
    sy = 600 / image.size[1]
    truth = template_subset(read_template(rec["template_path"])) * np.array([sx, sy])
    image = image.resize((600, 600))
    with ts.make_landmarker(run, num_faces=1) as still:
        reference = ts.predict_subset(still.detect(image), *image.size)
    iod_ref = inter_ocular_distance(reference, EYE_CORNERS)
    iod_truth = inter_ocular_distance(truth, EYE_CORNERS)
    frames = [perturb(image, "roll", float(8.0 * np.sin(2 * np.pi * k / ts.VIDEO_FRAMES))) for k in range(ts.VIDEO_FRAMES)]
    p3 = {"reference_vs_annotation_nme_frame0_geometry": round(nme_iod(reference, truth, iod_truth), 4)}
    for mode in ("IMAGE", "VIDEO"):
        vs_ref, vs_truth = [], []
        with ts.make_landmarker(run, num_faces=1, running_mode=mode) as lm:
            for k, (frame, forward) in enumerate(frames):
                faces = lm.detect(frame) if mode == "IMAGE" else lm.detect_frame(frame, int(k * 1000 / ts.VIDEO_FPS) + 1)
                pred = ts.predict_subset(faces, *frame.size)
                if pred is None:
                    continue
                vs_ref.append(nme_iod(pred, apply_affine(forward, reference), iod_ref))
                vs_truth.append(nme_iod(pred, apply_affine(forward, truth), iod_truth))
        p3[mode] = {
            "tracked": len(vs_ref),
            "nme_vs_moved_still_prediction (notebook metric)": round(float(np.mean(vs_ref)), 4),
            "nme_vs_moved_annotation": round(float(np.mean(vs_truth)), 4),
            "frame0_vs_moved_still_prediction": round(float(vs_ref[0]), 5),
        }
    results["P3_video_mode"] = p3

    # ---------------- P6: what the records hold ----------------
    out = run.out
    prep = json.loads((out / "prepare.json").read_text())
    inf = json.loads((out / "inference.json").read_text())
    res = json.loads((out / "mediapipe_face_landmarker_result.json").read_text())
    results["P6_records"] = {
        "prepare_keys": sorted(prep),
        "inference_keys": sorted(inf),
        "result_keys": sorted(res),
        "result_has_file_listing": any(k in res for k in ("files", "listing", "outputs")),
        "result_has_refusal_probes": "probes" in json.dumps(res) or "refus" in json.dumps(res),
        "result_has_run_id": any(k in res for k in ("run_id", "run_directory")),
    }
    (a.out / "results.json").write_text(json.dumps(results, indent=1, default=str))
    print(json.dumps(results, indent=1, default=str))


if __name__ == "__main__":
    main()
